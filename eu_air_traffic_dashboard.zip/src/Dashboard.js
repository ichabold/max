import React, { useEffect, useState } from 'react';

export default function Dashboard() {
  const [query, setQuery] = useState('');
  const [ready, setReady] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.ethereum) {
      console.info(
        'Portefeuille Web3 détecté (ex: MetaMask), mais ce tableau de bord ne l\'utilise pas.'
      );
    }
    setReady(true);
  }, []);

  if (!ready) {
    return <div style={{ padding: 20, fontFamily: 'sans-serif' }}>Chargement du tableau de bord…</div>;
  }

  const airports = [
    { iata: 'LHR', city: 'London', delay: 14 },
    { iata: 'CDG', city: 'Paris', delay: 20 },
    { iata: 'AMS', city: 'Amsterdam', delay: 16 }
  ];

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif', maxWidth: 800, margin: '0 auto' }}>
      <h1>EU Air Traffic Delays – Prototype</h1>
      <p>
        Ce tableau de bord affiche des données fictives sur les retards dans les principaux aéroports européens.
        Il ne se connecte pas à MetaMask et fonctionne indépendamment de tout portefeuille Web3.
      </p>

      <input
        type="text"
        placeholder="Rechercher un aéroport"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{ padding: 8, width: '100%', maxWidth: 300, marginBottom: 20 }}
      />

      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <th style={{ borderBottom: '1px solid #ccc', textAlign: 'left', padding: 8 }}>Code IATA</th>
            <th style={{ borderBottom: '1px solid #ccc', textAlign: 'left', padding: 8 }}>Ville</th>
            <th style={{ borderBottom: '1px solid #ccc', textAlign: 'left', padding: 8 }}>Retard moyen (min)</th>
          </tr>
        </thead>
        <tbody>
          {airports
            .filter(a => a.city.toLowerCase().includes(query.toLowerCase()) || a.iata.toLowerCase().includes(query.toLowerCase()))
            .map(a => (
              <tr key={a.iata}>
                <td style={{ padding: 8 }}>{a.iata}</td>
                <td style={{ padding: 8 }}>{a.city}</td>
                <td style={{ padding: 8 }}>{a.delay}</td>
              </tr>
            ))}
        </tbody>
      </table>

      <div style={{ marginTop: 20, padding: 10, background: '#eee' }}>
        ✅ Prototype prêt. Aucun appel MetaMask ici.
      </div>
    </div>
  );
}
